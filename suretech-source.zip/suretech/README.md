# SureTech

A small static replacement homepage for SureTech.live. White, charcoal and restrained blue; original geometric S monogram, editable SVG wordmark and favicon. Exact requested hero. Insurance Technology, Cloud Infrastructure, Data, Cybersecurity, About, Contact and footer.

## Quickest GitHub Pages deployment

1. Create an empty public GitHub repository, such as `suretech-site`.
2. Put **the contents of this directory** at the repository root, including `.github/workflows/pages.yml` and `.nojekyll`, and push to `main`.
3. In the repository, open **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Open **Actions → Deploy to GitHub Pages → Run workflow** (or push another commit). After it succeeds, open the URL in the deployment job, normally `https://YOUR-USERNAME.github.io/suretech-site/`.

Do not configure a custom domain. No CNAME file is included. No DNS changes are required or performed. Prefer a new repository so the existing site's deployment remains separate.

## Contact

SureTech Team — info@suretech.live. The homepage includes a direct email link.

## Build and preview

Requires Node.js 22 or newer. There are no packages to install.

```sh
npm run build
python3 -m http.server 4173 --directory dist
```

Open http://localhost:4173. Upload only `dist/` if deploying manually. GitHub Actions builds and uploads this directory automatically. Relative assets support both repository and account Pages URLs.

## Files

- `src/index.html`: semantic page, content, metadata and navigation.
- `src/styles.css`: responsive styling, keyboard focus, reduced-motion and print support.
- `src/assets/mark.svg`: scalable S monogram and favicon.
- `src/assets/wordmark.svg`: editable SureTech wordmark using local Arial/Helvetica lettering.
- `scripts/build.mjs`: clean production copy and validation of required sections, exact hero, duplicate IDs, links, assets and 40 KB size budget.
- `.github/workflows/pages.yml`: GitHub Pages build and deployment.
- `dist/`: generated production site (excluded from Git).

## Performance

Zero client JavaScript, zero package dependencies, zero external fonts, zero analytics, zero third-party requests. About 12 KB total source assets (about 4.3 KB gzip estimate; actual hosting compression varies). No runtime or backend is needed. Image dimensions are reserved to prevent layout shift. This is a size measurement, not a Lighthouse score or field performance measurement.
