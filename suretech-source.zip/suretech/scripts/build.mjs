import { cp, mkdir, readFile, readdir, rm, stat } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const src = resolve(root, 'src');
const html = await readFile(resolve(src, 'index.html'), 'utf8');
const required = ['insurance','cloud','data','cybersecurity','about','contact','expertise','main'];
for (const id of required) if (!html.includes(`id="${id}"`)) throw Error(`Missing section: ${id}`);
if (!html.includes('Technology built for businesses that cannot afford uncertainty.')) throw Error('Hero copy changed');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
if (new Set(ids).size !== ids.length) throw Error('Duplicate IDs');
for (const [,url] of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
  if (url.startsWith('#')) { if (url.length > 1 && !ids.includes(url.slice(1))) throw Error(`Broken anchor ${url}`); }
  else if (!/^(mailto:|https?:|data:)/.test(url)) await stat(resolve(src,url));
}
if (/<script\b|https?:\/\//.test(html)) throw Error('Unexpected script or external request in HTML');
await rm(resolve(root,'dist'), { recursive:true, force:true });
await mkdir(resolve(root,'dist'), { recursive:true });
await cp(src,resolve(root,'dist'), { recursive:true });
await cp(resolve(root,'.nojekyll'),resolve(root,'dist','.nojekyll'));
let total=0,compressed=0;
async function tally(dir) { for(const entry of await readdir(dir,{withFileTypes:true})) { const path=resolve(dir,entry.name); if(entry.isDirectory()) await tally(path); else { const data=await readFile(path); total+=data.length; compressed+=gzipSync(data).length; } } }
await tally(resolve(root,'dist'));
if(total>40000) throw Error('40 KB site budget exceeded');
console.log(`Production check passed. All sections, anchors and assets valid. ${total} bytes total; ${compressed} bytes gzip estimate. Zero client JavaScript, zero dependencies.`);
if(html.includes('contact-pending')) console.log('RELEASE NOTE: A verified contact address is still required; see README.');
